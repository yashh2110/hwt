<?php 
$razor_pay_key_id = 'rzp_test_uOKqqMlxqR5MZ2';
$secret_key = 'Ch4v86A9iI7Hfym9WZiPaFiq';
?>