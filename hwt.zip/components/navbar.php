<nav class="navbar homenav navbar-expand-sm p-0 m-0">
    <div class="navbutton">
    <div id="navicon" class="navicon">
      <span class="navs" id="s1"></span>
      <span class="navs" id="s2"></span>
      <span class="navs" id="s3"></span>
    </div>
    </div>

    <ul  class="navbar-nav nav navlist">
    <a href="http://localhost/hwt/donate" class="donate"><li class="nav-item donate">Donate</li></a>
        <a  href="http://localhost/hwt/about"><li id="about" class="nav-item">About Us</li></a>
        <a  href="http://localhost/hwt/ourwork"><li id="ourwork" class="nav-item">Our work</li></a>
        <a  href="http://localhost/hwt/gallery"><li id="gallery" class="nav-item">Gallery</li></a>
        <a  href="http://localhost/hwt/index#volenteer-form"><li class="nav-item">Engage</li></a>
        <a  href=""><li id="contact" class="nav-item">Contact Us</li></a>
    </ul>
    <div class="nav-item ml-auto pr-2">
    <a href="http://localhost/hwt/index"><h4  class="logo"><b style="color:rgb(211,8,8)">Human</b> Welfare Trust</h4></a>
    </div>
</nav>
