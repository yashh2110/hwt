<link rel="stylesheet" href="./node_modules/aos/dist/aos.css" />
<link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="./node_modules/owl.carousel/dist/assets/owl.carousel.min.css" />