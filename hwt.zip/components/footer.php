<div>
<div class="container-sm bg-white footertop" >
    <a class="text-white" href="http://localhost/hwt/donate">Donate</a>
    <a class="text-white">Volenteer</a>
    <a class="text-white">Reach Us</a>
</div>
<div class="container-fluid-sm bg-dark footer">
    <div class="container-sm footerlistdiv">
        <div>
            <p><b>Know Us</b></p>
            <ul class="footerlist">
                <li><span><a href="http://localhost/hwt/about">About Us</a></span></li>
                <li><span><a href="http://localhost/hwt/about#whyus">Why Us</a></span></li>
                <li><span><a href="http://localhost/hwt/donate">Donate</a></span></li>
                <li><span><a href=""><i class="fa fa-phone"></i> 939393939</a></span></li>
            </ul>
        </div>
        <div>
             <p><b>Get Involved</b></p>
            <ul class="footerlist">
                <li><span><a href="">Support campain</a></span></li>
                <li><span><a href="">Become a volenteer</a></span></li>
                <li><span><a href="">call to donate</a></span></li>
            </ul>
        </div>
        <div>
             <p><b>Achievments</b></p>
            <ul class="footerlist">
                <li><span><a href="">lorem ipsum</a></span></li>
                <li><span><a href="">ipsum lorem</a></span></li>
                <li><span><a href="">dolerm ipsum</a></span></li>
            </ul>
        </div>
        <div>
             <p><b>We Focus On</b></p>
            <ul class="footerlist">
                <li><span><a href="">education for children</a></span></li>
                <li><span><a href="">Food and Shelter for poor</a></span></li>
                <li><span><a href="">hygenes</a></span></li>
                <li><span><a href="">medical support</a></span></li>
            </ul>
        </div>
        <div>
             <p><b>Contact Us</b></p>
            <ul class="footerlist">
                <li><span><a href="">Instagram</a></span></li>
                <li><span><a href="">Facebook</a></span></li>
                <li><span><a href="">Twetter</a></span></li>
                <li><span><a href="">call</a></span></li>
            </ul>
        </div>
        <div style="width:220px" class="pt-3">
            <h3 class="text-right"><b>Human Welfare Trust</b></h3>
            <form class="form-group p-2">
                <input type="text" class="form-control m-2" placeholder="Name">
                <input type="email" class="form-control m-2" placeholder="Email">
                <button type="button" class="btn text-white m-2" style="background-color: rgb(211, 8, 8);" >Subscribe</button>
            </form>
        </div>

    </div>
    <hr >
    <p class="text-center">Copyright © 2021 All rights reserved</p>

</div>
</div>
