<?php
  session_start();
 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <?php
       include "./components/links.php";
      ?>
     <link rel="stylesheet" href="./css/index.css">
     <title>Admin Panel | Human Welfare Trust Delhi</title>
   </head>
   <body>

     <?php
       include "./components/scripts.php"
      ?>
      <script src="./js/index.js"></script>
   </body>
 </html>
