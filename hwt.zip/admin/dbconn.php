<?php
  $host="localhost";
  $name="root";
  $pass="";
  $db="hwt";
  $conn=mysqli_connect($host,$name,$pass,$db);

 ?>
