<div class="sidebar">
    <ul class="sidebar-item">
        <li>Donations</li>
        <li>Volenteer Applications</li>
        <li>Add Info</li>
        <li>Subscribed</li>
        <li>Send Mail</li>
        <li>Settings</li>
        <li>Create Account</li>
    </ul>
</div>
