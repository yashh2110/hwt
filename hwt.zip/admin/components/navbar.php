<nav class="navbar homenav navbar-expand-sm p-0 m-0">
    <!-- <div class="navbutton">
    <div id="navicon" class="navicon">
      <span class="navs" id="s1"></span>
      <span class="navs" id="s2"></span>
      <span class="navs" id="s3"></span>
    </div>
    </div> -->
    <div class="nav-item  pr-2">
    <a href="http://localhost/hwt/index"><h4  class="logo"><b style="color:rgb(211,8,8)">Human</b> Welfare Trust</h4></a>
    </div>
    <i class="down fas fa-arrow-down m-3"></i>
    <i class="up fas fa-arrow-up m-3"></i>
    <div class="user">
      <span class="far fa-user username"> Yashwanth muddana</span>
      <a href="#" class="fas fa-sign-out-alt username" style="color:rgb(211,8,8)">Logout</a>
    </div>
</nav>
