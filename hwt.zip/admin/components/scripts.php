<script src="../node_modules/jquery/dist/jquery.min.js"></script>
<script src="../node_modules/aos/dist/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="../node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<script>
    AOS.init();
</script>
